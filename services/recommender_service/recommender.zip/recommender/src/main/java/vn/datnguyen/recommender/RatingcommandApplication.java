package vn.datnguyen.recommender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RatingcommandApplication {

	public static void main(String[] args) {
		SpringApplication.run(RatingcommandApplication.class, args);
	}

}
