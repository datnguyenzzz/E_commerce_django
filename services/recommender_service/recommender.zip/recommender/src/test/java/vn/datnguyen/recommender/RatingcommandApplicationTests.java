package vn.datnguyen.recommender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RatingcommandApplicationTests {

	@Test
	void contextLoads() {
	}

}
